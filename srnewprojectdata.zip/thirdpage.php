 <?php require_once('head.php'); ?>
<body>
    <div class="container-fluid main_container">

  <div class="wrapper main_wrapper_second">
      
      <?php require_once('header.php'); ?>
      
      <!--<div class="row">-->
      <!--     <ul class="carosuel_dataimg">-->
      <!--         <li class="imgli_data">-->
      <!--                 <img src="logopalace.png">-->
      <!--          </li>-->
      <!--          <li class="secondli">-->
      <!--               <strong><p>Amet minim mollit non</p></strong>-->
      <!--               <p>2972 Westheimer Rd. Santa Ana, Illinois 85486 </p>-->
      <!--           </li>-->
      <!--     </ul>-->
      <!--</div>-->

      <div class="row headerhr_row">
          
          <hr>
      </div>
      
        <?php require_once('bannerinclude.php') ?>
   
     <!-- <div class="carosuel_data">-->
     <!--             <div id="demo" class="carousel slide" data-ride="carousel">-->

                        <!-- Indicators -->
     <!--                   <ul class="carousel-indicators">-->
     <!--                       <li data-target="#demo" data-slide-to="0" class="active main_carousel_indicator"></li>-->
     <!--                       <li data-target="#demo" data-slide-to="1" class="main_carousel_indicator"></li>-->
     <!--                       <li data-target="#demo" data-slide-to="2" class="main_carousel_indicator"></li>-->
     <!--                   </ul>-->
                        
                        <!-- The slideshow -->
     <!--                   <div class="carousel-inner carousel_data carousel_data_second ">-->
                            
     <!--                       <div class="carousel-item active">-->
     <!--                       <img src="caroseul_img1.png" class="carosuel_main_image" alt="Los Angeles" width="1100" height="500">-->
                              
     <!--                       </div>-->
                            
     <!--                       <div class="carousel-item">-->
     <!--                       <img src="caroseul_img2.jpg" alt="Chicago" class="carosuel_main_image" width="1100" height="500">-->
                            
     <!--                       </div>-->
                        
     <!--                   </div>-->
                        
        
                        <!-- Left and right controls -->
                        <!-- <a class="carousel-control-prev" href="#demo" data-slide="prev">
     <!--                       <span class="carousel-control-prev-icon"></span>-->
     <!--                   </a>-->
     <!--                   <a class="carousel-control-next" href="#demo" data-slide="next">-->
     <!--                       <span class="carousel-control-next-icon"></span>-->
     <!--                   </a> -->
     <!--               </div>-->
                    
            
                    
     <!--</div>-->
     
     
      
  </div>





   <div class="blackwrapper blackdata third_pagedata">
      <div class="black_morerow black_status_new"> 
             
            <div class="row blackdata">
          
                 <div class="col-sm-2 projects_data">
                      <h5 class="project_data">Sq.ft</h5>
                      <h5 class="project_no">35 000</h5>
                 </div>
                 
                 <div class="col-sm-2 projects_data">
                       <h5 class="project_data">Floors</h5>
                       <h5 class="project_no">72</h5>
                 </div>
                 
                 <div class="col-sm-2 projects_data">
                      <h5 class="project_data">Blocks</h5>
                      <h5 class="project_no">12</h5>
                 </div>
                 
                 <div class="col-sm-2 projects_data">
                     <h5 class="project_data">Flats</h5>
                      <h5 class="project_no">652</h5>
                 </div>
                 
                  <div class="col-sm-2 projects_data">
                     <h5 class="project_data">Status</h5>
                      <h5 class="project_no">???</h5>
                 </div>
                 
                  <div class="col-sm-2 projects_data">
                     <h5 class="project_data">Approvals</h5>
                      <h5 class="project_no">326</h5>
                 </div>
                 
          </div>
             
             
          </div>
      </div>
   </div>
   
   <!--<div class="blackwrapper mt-5">-->
   <!--   <div class="row blackdata">-->
          
   <!--      <div class="col-sm-2 projects_data">-->
   <!--           <h5 class="project_data">Sq.ft</h5>-->
   <!--           <h5 class="project_no">35 000</h5>-->
   <!--      </div>-->
         
   <!--      <div class="col-sm-2 projects_data">-->
   <!--            <h5 class="project_data">Floors</h5>-->
   <!--            <h5 class="project_no">72</h5>-->
   <!--      </div>-->
         
   <!--      <div class="col-sm-2 projects_data">-->
   <!--           <h5 class="project_data">Blocks</h5>-->
   <!--           <h5 class="project_no">12</h5>-->
   <!--      </div>-->
         
   <!--      <div class="col-sm-2 projects_data">-->
   <!--          <h5 class="project_data">Flats</h5>-->
   <!--           <h5 class="project_no">652</h5>-->
   <!--      </div>-->
         
   <!--       <div class="col-sm-2 projects_data">-->
   <!--          <h5 class="project_data">Status</h5>-->
   <!--           <h5 class="project_no">???</h5>-->
   <!--      </div>-->
         
   <!--       <div class="col-sm-2 projects_data">-->
   <!--          <h5 class="project_data">Approvals</h5>-->
   <!--           <h5 class="project_no">326</h5>-->
   <!--      </div>-->
         
   <!--   </div>-->
   <!--</div>-->


        <div class="company_detail_demo">
            <div class="black_morerow_third row">
             
                 <div class="col-sm-12 overview_center">
                     <h3>Overview</h3>
                  </div>
                  
                  <div class="col-sm-12 mt-4 overview_para">
                      
                      <p>Aliqua id fugiat nostrud irure ex duis ea quis id quis ad et. Sunt qui esse pariatur duis deserunt mollit dolore cillum minim tempor enim. Elit aute irure tempor cupidatat incididunt sint deserunt ut voluptate aute id deserunt nisi. Aliqua id fugiat nostrud irure ex duis ea quis id quis ad et. Sunt qui esse pariatur duis deserunt mollit dolore cillum minim tempor enim.</p>
                      <p>Elit aute irure tempor cupidatat incididunt sint deserunt ut voluptate aute id deserunt nisi.
                      Aliqua id fugiat nostrud irure ex duis ea quis id quis ad et. Sunt qui esse pariatur duis deserunt mollit dolore cillum minim tempor enim. Elit aute irure tempor cupidatat incididunt sint deserunt ut voluptate aute id deserunt nisi.
                      </p>
                      
                  </div>
          </div>
        </div>
       
         
         <div class="container mt-5">
             <h2 class="amenities_heading">Amenities</h2>
               <div class="row amenities_row">
                   <div class="col-sm-12">
                       
                       <?php for($i=0;$i<=14;$i++){ ?>
                       
                       <div class="start_col mt-4">
                           <p class="star_data"><i class="fa fa-star" aria-hidden="true"></i></p>
                           <p class="club_data">Club</p>
                           <p class="club_data">house</p>
                       </div>
                       
                       <?php } ?>
                      
                       
                   </div>
                       
               </div>
         </div>
         
         
         <div class="container-fluid mt-5">
             
             <div class="location_map">
                 <h3>Location Map</h3>
             </div>
             
             <div class="row mt-4">
                  <div class="googlemap">
                      <img src="GoogleMapTA.jpg">
                  </div>
             </div>
           
             
        </div>
        
        
        
        <div class="container-fluid mt-5">
             
             <div class="location_map">
                 <h3>Floor Plans</h3>
             </div>
             
             <div class="row mt-4">
                 
                 <div class="col-sm-6">

                   <div class="total_wrapperdata">  
                     <div class="col-sm-12 floorwrapper">
                    <h5>Floor</h5>
                 </div>

                   <div class="counting_sec">
                       <ul>
                           <li>1</li>
                           <li>2</li>
                           <li>3</li>
                           <li>4</li>
                           <li>5</li>
                       </ul>

                        <ul>
                           <li>6</li>
                           <li>7</li>
                           <li>8</li>
                           <li>9</li>
                           <li>10</li>
                       </ul>

                        <ul>
                           <li>11</li>
                           <li>12</li>
                       </ul>
                   </div> 

                   </div> 
                     <!-- <div class="counting_img">
                         <img src="counting.png">
                     </div> -->
                     
                 </div>
                 
                 <div class="col-sm-6">
                     <div class="floor_img">
                          <img src="floorimg.png">
                     </div>
                 </div>
             </div>
           
             
        </div>
        
        
          
        <div class="container-fluid mt-5">
             
             <div class="row mt-4">
                
                 <div class="col-sm-12">
                      <div class="carosuel_data">
                          <div id="demo2" class="carousel slide thridcarosuel_seconddata" data-ride="carousel">
        
                              
                                <ul class="carousel-indicators">
                                    <li data-target="#demo2" data-slide-to="0" class="active"></li>
                                    <li data-target="#demo2" data-slide-to="1"></li>
                                    <!-- <li data-target="#demo2" data-slide-to="2"></li> -->
                                </ul>
                                
                              
                                <div class="carousel-inner carousel_data carousel_data_secondcarousel">
                                    
                                    <div class="carousel-item thirdpage_carouseldata active">
                                    <img src="carouselmain_image2.png" alt="Los Angeles" width="1100" height="500">
                                    </div>
                                    
                                    <div class="carousel-item thirdpage_carouseldata">
                                    <img src="carouselmain_image1.png" alt="Chicago" width="1100" height="500">
                                    </div>
                                    
                                 
                                </div>
                                
                            
                            </div>
                      </div>
                 </div>
             </div>
        </div>
         
         <div class="container mt-5">
             
             <div class="location_map">
                 <h3>Latest Updates</h3>
             </div>
             
             <div class="row mt-5">
                 
                 <div class="col-sm-12">
                     
                         <div class="carosuel_data">
                          <div id="carousel-1" class="carousel slide thridcarosuel_seconddata" data-ride="carousel">
        
                              
                                <!--<ul class="carousel-indicators">-->
                                <!--    <li data-target="#demo" data-slide-to="0" class="active"></li>-->
                                <!--    <li data-target="#demo" data-slide-to="1"></li>-->
                                <!--    <li data-target="#demo" data-slide-to="2"></li>-->
                                <!--</ul>-->
                                
                              
                                <div class="carousel-inner carousel_data carousel_data_lastthird">
                                    
                                    <div class="carousel-item thirdpage_carouseldata thirdpage_secondportion active">
                                         
                                        <div class="row"> 
                                          <div class="col-sm-6">
                                             <div class="home_img">
                                                 <img src="home.png">
                                             </div>
                                          </div>
                                          
                                          <div class="col-sm-6 z">
                                                 <div  class="thirddate_div">
                                                     <p>21 January 2021</p>
                                                     <p>Aliqua id fugiat nostrud irure ex duis ea quis id quis ad et. Sunt qui esse pariatur duis deserunt mollit dolore cillum minim tempor enim. Elit aute irure tempor cupidatat incididunt sint deserunt ut voluptate aute id deserunt nisi.
                            Aliqua id fugiat nostrud irure ex duis ea quis id quis ad et. Sunt qui esse pariatur duis deserunt mollit dolore cillum minim tempor enim. Elit aute irure tempor cupidatat incididunt sint deserunt ut voluptate aute id deserunt nisi.</p>
                                                 </div>
                                         </div>
                                          
                                            <hr class="datahr_new">   
                                          
                                         </div>
                                    </div>
                                    
                                    
                                    
                                    <div class="carousel-item thirdpage_carouseldata thirdpage_secondportion">
                                         
                                        <div class="row"> 
                                          <div class="col-sm-6">
                                             <div class="home_img">
                                                 <img src="home.png">
                                             </div>
                                          </div>
                                          
                                          <div class="col-sm-6 z">
                                                 <div  class="thirddate_div">
                                                     <p>21 January 202</p>
                                                     <p>Aliqua id fugiat nostrud irure ex duis ea quis id quis ad et. Sunt qui esse pariatur duis deserunt mollit dolore cillum minim tempor enim. Elit aute irure tempor cupidatat incididunt sint deserunt ut voluptate aute id deserunt nisi.
                            Aliqua id fugiat nostrud irure ex duis ea quis id quis ad et. Sunt qui esse pariatur duis deserunt mollit dolore cillum minim tempor enim. Elit aute irure tempor cupidatat incididunt sint deserunt ut voluptate aute id deserunt nisi.</p>
                                                 </div>
                                         </div>
                                          
                                            <hr class="datahr_new">   
                                          
                                         </div>
                                    </div>
                                    
                                    
            
                                </div>
                                
                                 
                                  <!-- Left and right controls -->
                    <div>              
                                 
                              
                         <a class="carousel-control-next third_control_next" href="#carousel-1" data-slide="next">
                            <span class="carousel-control-next-icon"></span>
                        </a>
                        
                         <a class="carousel-control-prev third_control_prev" href="#carousel-1" data-slide="prev">
                            <span class="carousel-control-prev-icon"></span>
                        </a>
                        
                                 
                    </div>            
                            
                            </div>
                      </div>
                      
                      
                     
                     
                 </div>
                 

                 
                 <div class="col-sm-12 text-center enquire_nowdata">
                     <h3>Enquire Now</h3>
                 </div>
                 

                 <div class="col-sm-12">

                    <div class="contact_form">
                        <form>
                                <div class="row">
                                        
                                        <div class="col">
                                        <input type="text" class="form-control name_form" placeholder="Name">
                                        </div>
                                        
                                        <div class="col">
                                        <input type="text" class="form-control name_form" placeholder="Phone">
                                        </div>
                                </div>
                                
                                <div class="form-group mt-2">
                                        <textarea class="form-control name_form" id="exampleFormControlTextarea1" rows="4" placeholder="Comments"></textarea>
                                </div>
                                
                                <div class="row">
                                        
                                        <div class="col pr-0">
                                        <p>Amet minim mollit non deserunt</p>
                                        </div>
                                        
                                        <div class="col contact_send_btn">
                                        <button type="button" class="btn btn-primary send_formbtn">Send</button>
                                        </div>
                                </div>
                                
                                
                            </form>
                    </div>
                 </div>
                 <!--<div class="col-sm-6">-->
                     
                 <!--    <div class="home_img">-->
                 <!--        <img src="home.png">-->
                 <!--    </div>-->
                     
                 <!--</div>-->
                 
<!--                 <div class="col-sm-6">-->
<!--                     <div>-->
<!--                         <p>21 January 2021</p>-->
<!--                         <p>Aliqua id fugiat nostrud irure ex duis ea quis id quis ad et. Sunt qui esse pariatur duis deserunt mollit dolore cillum minim tempor enim. Elit aute irure tempor cupidatat incididunt sint deserunt ut voluptate aute id deserunt nisi.-->
<!--Aliqua id fugiat nostrud irure ex duis ea quis id quis ad et. Sunt qui esse pariatur duis deserunt mollit dolore cillum minim tempor enim. Elit aute irure tempor cupidatat incididunt sint deserunt ut voluptate aute id deserunt nisi.</p>-->
<!--                     </div>-->
<!--                 </div>-->

             </div>
           
             
        </div>
        
         
  </div>
   <?php require_once('footer.php'); ?>
</body>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>